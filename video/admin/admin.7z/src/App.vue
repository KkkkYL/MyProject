<template>
    
    <router-view/>
</template>

<style>
body{
    margin:0;
}

.avue-upload__avatar{
    height: auto !important;
}
</style>
