import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _00dd7a7f = () => interopDefault(import('..\\pages\\comments\\index.vue' /* webpackChunkName: "pages/comments/index" */))
const _387f2909 = () => interopDefault(import('..\\pages\\courses\\index.vue' /* webpackChunkName: "pages/courses/index" */))
const _6669d90a = () => interopDefault(import('..\\pages\\inspire.vue' /* webpackChunkName: "pages/inspire" */))
const _1aa5d9b1 = () => interopDefault(import('..\\pages\\courses\\_id.vue' /* webpackChunkName: "pages/courses/_id" */))
const _2f7f3bb3 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/comments",
    component: _00dd7a7f,
    name: "comments"
  }, {
    path: "/courses",
    component: _387f2909,
    name: "courses"
  }, {
    path: "/inspire",
    component: _6669d90a,
    name: "inspire"
  }, {
    path: "/courses/:id",
    component: _1aa5d9b1,
    name: "courses-id"
  }, {
    path: "/",
    component: _2f7f3bb3,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
