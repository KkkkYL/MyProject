<!-- eslint-disable vue/multi-word-component-names -->
<template lang="">
  <div>
    评论列表
  </div>
</template>
<script>
export default {
  
}
</script>
<style lang="">
  
</style>